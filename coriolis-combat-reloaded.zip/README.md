**To do**

* Sort out initiative
* Sort out custom crit on the item card
* Update NPCs/Creatures
* Add Compendia
